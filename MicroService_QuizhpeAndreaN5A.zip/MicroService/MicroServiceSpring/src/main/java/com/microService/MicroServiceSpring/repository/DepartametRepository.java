package com.microService.MicroServiceSpring.repository;

import com.microService.MicroServiceSpring.entity.Departament;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepartametRepository extends JpaRepository<Departament, Integer> {
}
