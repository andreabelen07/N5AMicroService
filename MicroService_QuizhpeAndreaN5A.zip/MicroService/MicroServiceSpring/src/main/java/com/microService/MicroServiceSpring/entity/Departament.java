package com.microService.MicroServiceSpring.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity //define que es una entidad de base de datos
@Table(name="departaments") // nombre de la tabla
@Data //defino los gettter y setter para las clases
@AllArgsConstructor //defino constructor con todos los parametros
@NoArgsConstructor //un constructor vacio
public class Departament {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String name;
    private String code;
}
