package com.microService.MicroServiceSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroServiceSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroServiceSpringApplication.class, args);
	}

}
