package com.microService.MicroServiceSpring.service;


import com.microService.MicroServiceSpring.entity.Departament;
import com.microService.MicroServiceSpring.repository.DepartametRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartamentService {
    private final DepartametRepository departametRepository;

    public DepartamentService(DepartametRepository departametRepository) {
        this.departametRepository = departametRepository;
    }

    public Departament createDepartament(Departament departament){
        return  departametRepository.save(departament);
    }
    public Departament getDepartamentById(Integer id){
        return departametRepository.findById(id).get();
    }
    public List<Departament> findAll(){
       return departametRepository.findAll();

    }
}
