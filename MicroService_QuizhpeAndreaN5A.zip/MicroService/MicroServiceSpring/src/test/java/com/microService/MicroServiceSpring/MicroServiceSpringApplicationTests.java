package com.microService.MicroServiceSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServiceSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
